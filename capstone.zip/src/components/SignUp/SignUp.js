import React from 'react';
import { connect, useStore } from 'react-redux';

import SignUpForm from './SignUpForm';
import * as actionCreators from '../../actions/actions';

const SignUp = (props) => {
  console.log(props.products, props.users);
  const store = useStore();
  console.log(store.getState());
  return <SignUpForm onRegister={(data) => props.registerBtnHandler(data)} users={props.users} />;
};

const mapStateToProps = (state) => {
  console.log(state.user.users);
  console.log(state.productReducer.products); 
  return {
    users: state.user.users,
    products: state.productReducer.products
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    registerBtnHandler: (userData) => {
      dispatch(actionCreators.registerUser(userData));
    },
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(SignUp);
